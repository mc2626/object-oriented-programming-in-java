package cp213;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Wraps around an Order object to ask for MenuItems and quantities.
 *
 * @author Mila Cvetanovska
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2022-11-20
 */
public class Cashier {

    // Attributes
    private Menu menu = null;

    /**
     * Constructor.
     *
     * @param menu A Menu.
     */
    public Cashier(Menu menu) {
	this.menu = menu;
    }

    /**
     * Prints the menu.
     */
    private void printCommands() {
	System.out.println("\nMenu:");
	System.out.println(menu.toString());
	System.out.println("Press 0 when done.");
	System.out.println("Press any other key to see the menu again.\n");
    }

    /**
     * Asks for commands and quantities. Prints a receipt when all orders have been
     * placed.
     *
     * @return the completed Order.
     */
    public Order takeOrder() {
	System.out.println("Welcome to WLU Foodorama!");

	System.out.println();
	this.printCommands();

	Order current_order = new Order();
	Scanner scan = new Scanner(System.in);
	String receipt = "";
	boolean flag = true;
	int item = 0;
	int quantity;
	boolean valid_item = false;

	while (flag) {

	    try {
		System.out.print("Command: ");
		item = scan.nextInt();
		if (item >= 1 && item <= 7) {
		    valid_item = true;
		} else if (item == 0) {
		    flag = false;
		    valid_item = false;
		} else {

		    this.printCommands();
		    valid_item = false;
		}
	    } catch (InputMismatchException e) {
		System.out.println("Not a valid number");
		this.printCommands();
		valid_item = false;
		scan.nextLine();
	    }
	    if (valid_item) {
		try {
		    System.out.print("How many do you want: ");
		    quantity = scan.nextInt();
		    current_order.add(menu.getItem(item - 1), quantity);

		} catch (InputMismatchException e) {
		    System.out.println("Not a valid number");
		    scan.nextLine();
		}
	    }

	}
	scan.close();
	System.out.println("Receipt");
	receipt = current_order.toString();
	System.out.println(receipt);
	return current_order;
    }

}