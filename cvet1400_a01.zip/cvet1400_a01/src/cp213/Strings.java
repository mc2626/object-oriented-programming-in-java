package cp213;

/**
 * @author Mila Cvetanovska, 210311400
 * @version 2022-01-08
 */
public class Strings {
    // Constants
    public static final String VOWELS = "aeiouAEIOU";

    /**
     * Determines if string is a "palindrome": a word, verse, or sentence (such as
     * "Able was I ere I saw Elba") that reads the same backward or forward. Ignores
     * case, spaces, digits, and punctuation in the string parameter s.
     *
     * @param string a string
     * @return true if string is a palindrome, false otherwise
     */
    public static boolean isPalindrome(final String string) {

	boolean is_palin = false;
	for (int i = 0; i < (string.length() / 2); i++) {
	    char ch1 = string.charAt(i);
	    char ch2 = string.charAt(string.length() - i - 1);
	    if (ch1 == ch2) {
		is_palin = true;
	    }
	}

	return is_palin;
    }

    /**
     * Determines if name is a valid Java variable name. Variables names must start
     * with a letter or an underscore, but cannot be an underscore alone. The rest
     * of the variable name may consist of letters, numbers and underscores.
     *
     * @param name a string to test as a Java variable name
     * @return true if name is a valid Java variable name, false otherwise
     */
    public static boolean isValid(final String name) {

	boolean valid = true;
	if (name.length() > 0) {
	    // check first character
	    char first = name.charAt(0);
	    String underscore = "_";
	    if (!Character.isLetter(first)) {
		// if underscore check length
		if (name.equals(underscore)) {
		    valid = false;
		} else if (Character.isDigit(first)) {
		    valid = false;
		}
	    }
	    // loop through to make sure there's no special characters
	    char b = '_';
	    Character u = new Character(b);
	    int i = 0;
	    int nameLength = name.length();
	    while (valid && i < nameLength) {
		Character temp = name.charAt(i);
		if ((!Character.isDigit(temp)) && (!Character.isLetter(temp)) && (!temp.equals(u))) {
		    valid = false;
		}

		i++;
	    }

	} else {
	    valid = false;
	}

	return valid;
    }

    /**
     * Converts a word to Pig Latin. The conversion is:
     * <ul>
     * <li>if a word begins with a vowel, add "way" to the end of the word.</li>
     * <li>if the word begins with consonants, move the leading consonants to the
     * end of the word and add "ay" to the end of that. "y" is treated as a
     * consonant if it is the first character in the word, and as a vowel for
     * anywhere else in the word.</li>
     * </ul>
     * Preserve the case of the word - i.e. if the first character of word is
     * upper-case, then the new first character should also be upper case.
     *
     * @param word The string to convert to Pig Latin
     * @return the Pig Latin version of word
     */
    public static String pigLatin(String word) {

	String pl = "";

	char ch = word.charAt(0);
	String ch_str = String.valueOf(ch);

	if (VOWELS.contains(ch_str)) {
	    pl += word + "way";

	} else {

//	    find the first letter in the word that is a vowel and get its index postion 
	    int vowel_pos = 0;
	    int i = 0;
	    boolean cond = true;

	    while ((cond) && (i < word.length())) {
		char ch1 = word.charAt(i);
		String ch_str1 = String.valueOf(ch1);

		if (VOWELS.contains(ch_str1)) {
		    vowel_pos = word.indexOf(ch1);
		    cond = false;
		} else {
		    cond = true;
		}

		i += 1;
	    }

	    if (Character.isUpperCase(ch)) {

//		Store the lowercased, cut up word in a temp pig_latin var
		String pl_temp = "";
		pl_temp += (word.substring(vowel_pos) + word.substring(0, vowel_pos) + "ay");
		String lower_pl_temp = pl_temp.toLowerCase();

//		find the first letter in the lower cased temp pl word
		String pl_str = String.valueOf(lower_pl_temp.charAt(0));

//		make first letter uppercase and add it the the lower cased temp pl word replacing the previous first letter
		pl += (pl_str.toUpperCase() + lower_pl_temp.substring(1));

	    } else {
		pl += (word.substring(vowel_pos) + word.substring(0, vowel_pos) + "ay");
	    }

	}

	return pl;
    }
}
