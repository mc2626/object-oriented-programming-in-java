package cp213;

/**
 * @author Mila Cvetanovska, 210311400
 * @version 2022-01-08
 */
public class Cipher {
    // Constants
    public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final int ALPHA_LENGTH = ALPHA.length();

    /**
     * Encipher a string using a shift cipher. Each letter is replaced by a letter
     * 'n' letters to the right of the original. Thus for example, all shift values
     * evenly divisible by 26 (the length of the English alphabet) replace a letter
     * with itself. Non-letters are left unchanged.
     *
     * @param s string to encipher
     * @param n the number of letters to shift
     * @return the enciphered string
     */
    public static String shift(final String s, final int n) {

	String estring = "";
	for (int i = 0; i < s.length(); i++) {
	    char ch = s.charAt(i);
	    if ((Character.isLetter(ch)) & (Character.isUpperCase(ch))) {
		int ascii_ch = ch;
		int int_new_ch = ((ascii_ch + n - 65) % 26 + 65);
		char new_ch = (char) int_new_ch;
		estring += new_ch;
	    } else {
		int ascii_ch = ch;
		int int_new_ch = ((ascii_ch + n - 97) % 26 + 97);
		char new_ch = (char) int_new_ch;
		estring += new_ch;
	    }

	}

	return estring;
    }

    /**
     * Encipher a string using the letter positions in ciphertext. Each letter is
     * replaced by the letter in the same ordinal position in the ciphertext.
     * Non-letters are left unchanged. Ex:
     *
     * <pre>
    Alphabet:   ABCDEFGHIJKLMNOPQRSTUVWXYZ
    Ciphertext: AVIBROWNZCEFGHJKLMPQSTUXYD
     * </pre>
     *
     * A is replaced by A, B by V, C by I, D by B, E by R, and so on. Non-letters
     * are ignored.
     *
     * @param s          string to encipher
     * @param ciphertext ciphertext alphabet
     * @return the enciphered string
     */
    public static String substitute(final String s, final String ciphertext) {

	String estring = "";
	for (int i = 0; i < s.length(); i++) {
	    char ch = s.charAt(i);
	    if (Character.isLetter(ch)) {
		for (int j = 0; j < ALPHA.length(); j++) {
		    char ALPHA_ch = ALPHA.charAt(j);
		    if (Character.toUpperCase(ch) == ALPHA_ch) {
			char ciph_ch = ciphertext.charAt(j);
			estring += ciph_ch;
		    }

		}

	    }
	}

	return estring;
    }

}
