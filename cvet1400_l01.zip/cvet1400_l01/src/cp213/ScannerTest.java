package cp213;

import java.util.Scanner;

/**
 * Class to demonstrate the use of Scanner with a keyboard and File objects.
 *
 * @author Mila Cvetanovska
 * @version 2022-01-08
 */
public class ScannerTest {

    /**
     * Count lines in the scanned file.
     *
     * @param source Scanner to process
     * @return number of lines in scanned file
     */
    public static int countLines(final Scanner source) {
	int count = 0;

	while (source.hasNextLine()) {
	    count += 1;
	    source.nextLine();
	}
	source.close();
	return count;
    }

    /**
     * Count tokens in the scanned object.
     *
     * @param source Scanner to process
     * @return number of tokens in scanned object
     */
    public static int countTokens(final Scanner source) {
	int tokens = 0;

	while (source.hasNext()) {
	    tokens += 1;
	    source.next();

	}
	source.close();
	return tokens;
    }

    /**
     * Ask for and total integers from the keyboard.
     *
     * @param keyboard Scanner to process
     * @return total of positive integers entered from keyboard
     */
    public static int readNumbers(final Scanner keyboard) {

	System.out.println("Enter a series of integers. Press 'q' to quit.");
	int total = 0;
	String var = null;

	while (!keyboard.hasNext("q")) {

	    if (keyboard.hasNextInt()) {
		total += keyboard.nextInt();
		keyboard.nextLine();

	    } else {
		var = keyboard.nextLine();
		System.out.println(var + " not an integer");
	    }

	}

	keyboard.nextLine();
	return total;

    }

}
