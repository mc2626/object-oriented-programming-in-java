package cp213;

/**
 * A single linked list structure of <code>Node T</code> objects. These data
 * objects must be Comparable - i.e. they must provide the compareTo method.
 * Only the <code>T</code> value contained in the priority queue is visible
 * through the standard priority queue methods. Extends the
 * <code>SingleLink</code> class.
 *
 * @author Mila Cvetanovksa, 210311400, cvet1400@mylaurier.ca
 * @version 2022-10-26
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

    /**
     * Searches for the first occurrence of key in this SingleList. Private helper
     * methods - used only by other ADT methods.
     *
     * @param key The value to look for.
     * @return A pointer to the node previous to the node containing key.
     */
    private SingleNode<T> linearSearch(final T key) {

	SingleNode<T> nodeReturn = new SingleNode<T>(null, null);
	if (this.front != null) {
	    int i = 0;
	    SingleNode<T> node = new SingleNode<T>(null, this.front);
	    while (i < this.length) {
		if (node.getNext() != null) {
		    if (node.getNext().getDatum().equals(key)) {
			nodeReturn = node;
			break;
		    }
		}
		node = node.getNext();
		i++;
	    }
	}
	return nodeReturn;

    }

    /**
     * Appends data to the end of this SingleList.
     *
     * @param datum The value to append.
     */
    public void append(final T datum) {

	SingleNode<T> node = new SingleNode<T>(datum, null);

	if (this.front == null) {
	    this.front = node;
	} else {
	    this.rear.setNext(node);
	}
	this.rear = node;
	this.length += 1;

	return;
    }

    private void _helper_append(final T datum) {

	SingleNode<T> node = new SingleNode<T>(datum, null);

	if (this.front == null) {
	    this.front = node;
	} else {
	    this.rear.setNext(node);
	}
	this.rear = node;
	this.length += 1;

	return;
    }

    /**
     * Removes duplicates from this SingleList. The list contains one and only one
     * of each value formerly present in this SingleList. The first occurrence of
     * each value is preserved.
     */
    public void clean() {

	SingleList<T> temp1 = new SingleList<T>();
	SingleList<T> temp2 = new SingleList<T>();

	if (this.length > 1) {
	    while (this.front != null) {
		SingleNode<T> prev = temp1.linearSearch(this.front.getDatum());

//		if value is already in temp1 list
		if (prev.getNext() == null) {
		    temp1.moveFrontToRear(this);
		} else {
		    temp2.moveFrontToRear(this);
		}

	    }
//		this should be empty at this point so we are adding all values 
//		back from temp1

	    while (temp1.front != null) {
		this.moveFrontToRear(temp1);
	    }
	}

    }

    /**
     * Combines contents of two lists into a third. Values are alternated from the
     * origin lists into this SingleList. The origin lists are empty when finished.
     * NOTE: data must not be moved, only nodes.
     *
     * @param left  The first list to combine with this SingleList.
     * @param right The second list to combine with this SingleList.
     */
    public void combine(final SingleList<T> left, final SingleList<T> right) {

	if (this.front == null) {
	    while (left.front != null || right.front != null) {
		if (left.front != null) {
		    this.moveFrontToRear(left);
		}
		if (right.front != null) {
		    this.moveFrontToRear(right);
		}
	    }

	}

	return;
    }

    /**
     * Determines if this SingleList contains key.
     *
     * @param key The key value to look for.
     * @return true if key is in this SingleList, false otherwise.
     */
    public boolean contains(final T key) {

	boolean isValid = true;
	SingleNode<T> node = this.linearSearch(key);
	if (node.getDatum() == null) {
	    isValid = false;
	}

	return isValid;

    }

    /**
     * Finds the number of times key appears in list.
     *
     * @param key The value to look for.
     * @return The number of times key appears in this SingleList.
     */
    public int count(final T key) {

	int num = 0;

	if (this.front != null) {
	    SingleNode<T> curr = this.front;
	    while (curr != null) {
		if (curr != null) {
		    if (curr.getDatum() == key) {
			num += 1;
		    }
		}
		curr = curr.getNext();
	    }
	}

	return num;
    }

    /**
     * Finds and returns the value in list that matches key.
     *
     * @param key The value to search for.
     * @return The value that matches key, null otherwise.
     */
    public T find(final T key) {

	SingleNode<T> prev = this.linearSearch(key);
	T value = null;

	if (prev != null) {
	    if (prev.getNext() != null) {
		value = prev.getNext().getDatum();
	    }
	}

	return value;

    }

    /**
     * Get the nth item in this SingleList.
     *
     * @param n The index of the item to return.
     * @return The nth item in this SingleList.
     * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
     */
    public T get(final int n) throws ArrayIndexOutOfBoundsException {

	SingleNode<T> curr = this.front;
	T value = null;
	int i = 0;

	while (curr != null) {

	    if (i == n) {
		if (curr != null) {
		    value = curr.getDatum();
		}
	    }
	    curr = curr.getNext();
	    i += 1;
	}

	return value;
    }

    /**
     * Determines whether two lists are identical.
     *
     * @param source The list to compare against this SingleList.
     * @return true if this SingleList contains the same values in the same order as
     *         source, false otherwise.
     */
    public boolean identical(final SingleList<T> source) {

	boolean same = true;
	SingleNode<T> curr = this.front;
	SingleNode<T> source_curr = source.front;

	if (this.length != source.length) {
	    same = false;
	} else {
	    while (curr != null && source_curr != null) {
		if (curr.getDatum() != source_curr.getDatum()) {
		    same = false;
		}
		curr = curr.getNext();
		source_curr = source_curr.getNext();
	    }
	}

	return same;
    }

    /**
     * Finds the first location of a value by key in this SingleList.
     *
     * @param key The value to search for.
     * @return The index of key in this SingleList, -1 otherwise.
     */
    public int index(final T key) {

	SingleNode<T> curr = this.front;
	boolean cond = true;
	int i = -1;

	if (curr != null) {
	    int j = 0;
	    while (cond && curr != null) {
		if (curr != null) {
		    if (curr.getDatum() == key) {
			cond = false;
			i = j;
		    } else {
			cond = true;
			j += 1;
		    }
		    curr = curr.getNext();
		}

	    }
	}

	return i;
    }

    /**
     * Inserts value into this SingleList at index i. If i greater than the length
     * of this SingleList, append data to the end of this SingleList.
     *
     * @param i     The index to insert the new data at.
     * @param datum The new value to insert into this SingleList.
     */
    public void insert(int i, final T datum) {

	if ((this.length == 0) || (i > (this.length - 1))) {
	    this._helper_append(datum);
	} else if ((i == 0) || (i < -(this.length))) {
	    this._helper_prepend(datum);
	} else {
	    int index = -1;
	    SingleNode<T> current = this.front;

	    if (i > 0) {
		index = 0;
	    } else if (i < 0) {
		index = -(this.length);
	    }
	    while (index < (i - 1)) {
		current = current.getNext();
		index += 1;
	    }
	    SingleNode<T> node = new SingleNode<T>(datum, current.getNext());
	    current.setNext(node);

	}
	this.length += 1;

	return;
    }

    /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
    public void intersection(final SingleList<T> left, final SingleList<T> right) {

	if (this.front == null) {

	    SingleNode<T> leftCurr = left.front;

	    while (leftCurr != null) {
		SingleNode<T> prev = right.linearSearch(leftCurr.getDatum());

		if (prev != null) {
		    SingleNode<T> current = prev.getNext();
		    if (current != null) {
//			check if value already exists in this 

			SingleNode<T> thisCurr = this.front;
			if (thisCurr == null) {
			    this._helper_append(current.getDatum());
			} else {
			    boolean cond = true;
			    while (cond && thisCurr != null) {
				if (current.getDatum() == thisCurr.getDatum()) {
				    cond = false;
				} else {
				    cond = true;
				}
				thisCurr = thisCurr.getNext();

			    }
			    if (thisCurr == null) {
				this._helper_append(current.getDatum());
			    }

			}
		    }
//		    
		}

		leftCurr = leftCurr.getNext();
	    }

	}

	return;
    }

    /**
     * Finds the maximum value in this SingleList.
     *
     * @return The maximum value.
     */
    public T max() {

	T maxData = null;

	if (this.front != null) {
	    maxData = this.front.getDatum();
	    SingleNode<T> curr = this.front;
	    int count = 0;

	    while (curr != null && count < this.length) {
		if (curr.getDatum().compareTo(maxData) > 0) {
		    maxData = curr.getDatum();
		}
		curr = curr.getNext();
		count += 1;
	    }
	}
	return maxData;
    }

    /**
     * Finds the minimum value in this SingleList.
     *
     * @return The minimum value.
     */
    public T min() {

	T minData = null;

	if (this.front != null) {
	    minData = this.front.getDatum();
	    SingleNode<T> curr = this.front;
	    int count = 0;

	    while (curr != null && count < this.length) {
		if (curr.getDatum().compareTo(minData) < 0) {
		    minData = curr.getDatum();
		}
		curr = curr.getNext();
		count += 1;
	    }
	}
	return minData;
    }

    /**
     * Inserts value into the front of this SingleList.
     *
     * @param datum The value to insert into the front of this SingleList.
     */
    public void prepend(final T datum) {

	if (this.front == null) {
	    SingleNode<T> node1 = new SingleNode<T>(datum, null);
	    this.front = node1;
	    this.rear = node1;
	} else {
	    SingleNode<T> node2 = new SingleNode<T>(datum, this.front);
	    this.front = node2;
	}
	this.length += 1;

	return;
    }

    private void _helper_prepend(final T datum) {

	if (this.front == null) {
	    SingleNode<T> node1 = new SingleNode<T>(datum, null);
	    this.front = node1;
	    this.rear = node1;
	} else {
	    SingleNode<T> node2 = new SingleNode<T>(datum, this.front);
	    this.front = node2;
	}
	this.length += 1;

	return;
    }

    /**
     * Finds, removes, and returns the value in this SingleList that matches key.
     *
     * @param key The value to search for.
     * @return The value matching key, null otherwise.
     */
    public T remove(final T key) {

	SingleNode<T> prev = this.linearSearch(key);
	T value = null;

	if (this.length > 0) {
	    if (prev != null) {
		if (prev.getNext() != null) {
		    SingleNode<T> curr = prev.getNext();
		    value = curr.getDatum();

		    if (this.length == 1) {
			this.front = null;
			this.rear = null;
		    }
//		    remove first value
		    else if (this.front.getDatum() == key) {
			this.front = this.front.getNext();
		    }
//		    remove last value
		    else if (this.rear.getDatum() == key) {
			this.rear = prev;
			this.rear.setNext(null);
		    }
//		    everything else
		    else {
			curr = curr.getNext();
			prev.setNext(curr);
		    }
		    this.length -= 1;
		}
	    }

	}
	return value;
    }

    /**
     * Removes the value at the front of this SingleList.
     *
     * @return The value at the front of this SingleList.
     */
    public T removeFront() {

	T value = null;
	if (this.front != null) {
	    value = this.front.getDatum();
	    this.front = this.front.getNext();
	}
	this.length -= 1;

	return value;
    }

    /**
     * Finds and removes all values in this SingleList that match key.
     *
     * @param key The value to search for.
     */
    public void removeMany(final T key) {

	SingleList<T> temp1 = new SingleList<T>();
	SingleList<T> temp2 = new SingleList<T>();
	SingleNode<T> prev = this.linearSearch(key);

	while (this.front != null) {
	    if (prev != null) {
//		if value is exists in this
		if (prev.getNext() == null) {
		    temp1.moveFrontToRear(this);
		} else {
		    temp2.moveFrontToRear(this);
		}
	    }

	}
//	this should be empty at this point so we are adding all values 
//	back from temp1

	while (temp1.front != null) {
	    this.moveFrontToRear(temp1);
	}

	return;
    }

    /**
     * Reverses the order of the values in this SingleList.
     */
    public void reverse() {

	SingleNode<T> prev = null;
	SingleNode<T> curr = this.front;
	SingleNode<T> nxt = null;

	while (curr != null) {
	    nxt = curr.getNext();
	    curr.setNext(prev);
	    prev = curr;
	    curr = nxt;
	}
	this.rear = this.front;
	this.front = prev;

	return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move value or call the high-level methods insert
     * or remove. this SingleList is empty when done. The first half of this
     * SingleList is moved to left, and the last half of this SingleList is moved to
     * right. If the resulting lengths are not the same, left should have one more
     * item than right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void split(final SingleList<T> left, final SingleList<T> right) {

	int count = 0;
	int mid = this.length / 2 + this.length % 2;

	while (this.front != null && count < mid) {
	    SingleNode<T> curr = this.front;
	    left.moveFrontToRear(this);
	    curr = curr.getNext();
	    count += 1;
	}
	while (this.front != null) {
	    SingleNode<T> curr = this.front;
	    right.moveFrontToRear(this);
	    curr = curr.getNext();
	    count += 1;
	}

	return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move value or call the high-level methods insert
     * or remove. this SingleList is empty when done. Nodes are moved alternately
     * from this SingleList to left and right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {

	boolean alt = true;

	while (this.front != null) {
	    SingleNode<T> curr = this.front;
	    if (alt) {
		left.moveFrontToRear(this);
		alt = false;
	    } else {
		right.moveFrontToRear(this);
		alt = true;
	    }
	    curr = curr.getNext();
	}

	return;
    }

    /**
     * Creates a union of two other SingleLists into this SingleList. Copies value
     * to this list. left and right SingleLists are unchanged. Values from left are
     * copied in order first, then values from right are copied in order.
     *
     * @param left  The first SingleList to create a union from.
     * @param right The second SingleList to create a union from.
     */
    public void union(final SingleList<T> left, final SingleList<T> right) {

	if (this.front == null) {

	    SingleList<T> temp = new SingleList<T>();

	    while (left.front != null) {
		SingleNode<T> curr = this.front;
		while (curr != null) {
		    if (left.front != null) {
			if (left.front.getDatum() == curr.getDatum()) {
			    temp.moveFrontToRear(left);
			}
		    }
		    curr = curr.getNext();

		}
		if (left.front != null) {
		    this.moveFrontToRear(left);
		}
	    }

	    while (right.front != null) {
		SingleNode<T> curr = this.front;
		while (curr != null) {
		    if (right.front != null) {
			if (right.front.getDatum() == curr.getDatum()) {
			    temp.moveFrontToRear(right);
			}
		    }
		    curr = curr.getNext();

		}
		if (right.front != null) {
		    this.moveFrontToRear(right);
		}

	    }
	}

	return;
    }
}
