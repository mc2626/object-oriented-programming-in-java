package cp213;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Utilities for working with Food objects.
 *
 * @author Mila Cvetanovska, 210311400, cvet1400@mylaurier.ca
 * @version 2022-10-04
 */
public class FoodUtilities {

    /**
     * Determines the average calories in a list of foods. No rounding necessary.
     * Foods list parameter may be empty.
     *
     * @param foods a list of Food
     * @return average calories in all Food objects
     */
    public static int averageCalories(final ArrayList<Food> foods) {

	int average = 0;
	int total = 0;

	for (int i = 0; i < foods.size(); i++) {
	    total += foods.get(i).getCalories();
	}
	average = total / foods.size();
	return average;
    }

    /**
     * Determines the average calories in a list of foods for a particular origin.
     * No rounding necessary. Foods list parameter may be empty.
     *
     * @param foods  a list of Food
     * @param origin the origin of the Food
     * @return average calories for all Foods of the specified origin
     */
    public static int averageCaloriesByOrigin(final ArrayList<Food> foods, final int origin) {

	ArrayList<Food> food_origins = getByOrigin(foods, origin);
	int originsAverage = 0;
	int total = 0;

	for (int i = 0; i < food_origins.size(); i++) {
	    if (origin == food_origins.get(i).getOrigin()) {
		total = total + food_origins.get(i).getCalories();
	    }

	}
	originsAverage = total / food_origins.size();

	return originsAverage;

    }

    /**
     * Creates a list of foods by origin.
     *
     * @param foods  a list of Food
     * @param origin a food origin
     * @return a list of Food from origin
     */
    public static ArrayList<Food> getByOrigin(final ArrayList<Food> foods, final int origin) {

	ArrayList<Food> origins = new ArrayList<Food>();

	for (int i = 0; i < foods.size(); i++) {
	    if (origin == foods.get(i).getOrigin()) {
		origins.add(foods.get(i));
	    }

	}

	return origins;
    }

    /**
     * Creates a Food object by requesting data from a user. Uses the format:
     *
     * <pre>
    Name: name
    Origins
     0 Canadian
     1 Chinese
    ...
    11 English
    Origin: origin number
    Vegetarian (Y/N): Y/N
    Calories: calories
     * </pre>
     *
     * @param keyboard a keyboard Scanner
     * @return a Food object
     */
    public static Food getFood(final Scanner keyboard) {

	System.out.println("Name: ");
	String name = keyboard.nextLine();

	String menu = Food.originsMenu();
	System.out.println(menu);

	System.out.println("Origin: ");
	int origin = keyboard.nextInt();
	keyboard.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

	System.out.println("Vegetarian (Y/N): ");
	String veg_answer = keyboard.nextLine();
	Boolean isVegetarian = true;
	if (veg_answer.toLowerCase() == "n") {
	    isVegetarian = false;
	}

	System.out.println("Calories: ");
	int calories = keyboard.nextInt();

	Food food = new Food(name, origin, isVegetarian, calories);

	return food;
    }

    /**
     * Creates a list of vegetarian foods.
     *
     * @param foods a list of Food
     * @return a list of vegetarian Food
     */
    public static ArrayList<Food> getVegetarian(final ArrayList<Food> foods) {

	ArrayList<Food> veggie = new ArrayList<Food>();

	for (int i = 0; i < foods.size(); i++) {
	    if (foods.get(i).isVegetarian() == true) {
		veggie.add(foods.get(i));
	    }

	}

	return veggie;
    }

    /**
     * Creates and returns a Food object from a line of string data.
     *
     * @param line a vertical bar-delimited line of food data in the format
     *             name|origin|isVegetarian|calories
     * @return the data from line as a Food object
     */
    public static Food readFood(final String line) {

	String list[] = line.split(Pattern.quote("|"));

	String name = list[0];

	String origin_str = list[1];
	int origin = Integer.parseInt(origin_str);

	String veg_str = list[2];
	Boolean isVegetarian = Boolean.parseBoolean(veg_str);

	String cal_str = list[3];
	int calories = Integer.parseInt(cal_str);

	Food food = new Food(name, origin, isVegetarian, calories);

	return food;
    }

    /**
     * Reads a file of food strings into a list of Food objects.
     *
     * @param fileIn a Scanner of a Food data file in the format
     *               name|origin|isVegetarian|calories
     * @return a list of Food
     */
    public static ArrayList<Food> readFoods(final Scanner fileIn) {

	ArrayList<Food> foods = new ArrayList<Food>();

	while (fileIn.hasNextLine()) {
	    String line = fileIn.nextLine();
	    Food food = readFood(line);
	    foods.add(food);

	}

	return foods;
    }

    /**
     * Searches for foods that fit certain conditions.
     *
     * @param foods        a list of Food
     * @param origin       the origin of the food; if -1, accept any origin
     * @param maxCalories  the maximum calories for the food; if 0, accept any
     * @param isVegetarian whether the food is vegetarian or not; if false accept
     *                     any
     * @return a list of foods that fit the conditions specified
     */
    public static ArrayList<Food> foodSearch(final ArrayList<Food> foods, final int origin, final int maxCalories,
	    final boolean isVegetarian) {

	ArrayList<Food> reqFoods = new ArrayList<Food>();

	for (int i = 0; i < foods.size(); i++) {

	    if (origin == -1 || foods.get(i).getOrigin() == origin && foods.get(i).getCalories() <= maxCalories
		    && foods.get(i).isVegetarian() == false) {
		reqFoods.add(foods.get(i));
	    }

	}

	return reqFoods;
    }

    /**
     * Writes the contents of a list of Food to a PrintStream.
     *
     * @param foods a list of Food
     * @param ps    the PrintStream to write to
     */
    public static void writeFoods(final ArrayList<Food> foods, PrintStream ps) {

	for (int i = 0; i < foods.size(); i++) {
	    ps.println(foods.get(i));
	}

	return;

    }
}
